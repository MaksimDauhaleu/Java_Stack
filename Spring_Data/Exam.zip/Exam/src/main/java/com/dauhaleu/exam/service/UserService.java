package com.dauhaleu.exam.service;

import java.util.List;
import java.util.Optional;
import org.mindrot.jbcrypt.BCrypt;
import org.springframework.stereotype.Service;

import com.dauhaleu.exam.model.Task;
import com.dauhaleu.exam.model.User;
import com.dauhaleu.exam.repository.TaskRepository;
import com.dauhaleu.exam.repository.UserRepository;

@Service
public class UserService {
    private final UserRepository userRepository;
    private final TaskRepository taskRepository;
    
    public UserService(UserRepository userRepository, TaskRepository taskRepository) {
        this.userRepository = userRepository;
        this.taskRepository = taskRepository;
    }
    
    // register user and hash their password
    public User registerUser(User user) {
        String hashed = BCrypt.hashpw(user.getPassword(), BCrypt.gensalt());
        user.setPassword(hashed);
        return userRepository.save(user);
    }
    
    // find user by email
    public User findByEmail(String email) {
        return userRepository.findByEmail(email);
    }
    
    // find user by id
    public User findUserById(Long id) {
    	Optional<User> u = userRepository.findById(id);
    	
    	if(u.isPresent()) {
            return u.get();
    	} else {
    	    return null;
    	}
    }
    // authenticate user
    public boolean authenticateUser(String email, String password) {
    	User user = userRepository.findByEmail(email);
    	if(user == null) {
    		return false;
    	} else {
    		if(BCrypt.checkpw(password, user.getPassword())) {
    			return true;
    		} else {
    			return false;
    		}
    	}
    }
    // find task by id
    public Task findTaskById(Long id) {
    	Optional<Task> u = taskRepository.findById(id);
    	if(u.isPresent()) {
            return u.get();
    	} else {
    	    return null;
    	}
    }
    
    //Find All Tasks
    public List<Task> findTasks() {
    	return taskRepository.findAll();
    }
    
    //Find All Users
    public List<User> findUsers() {
    	return userRepository.findAll();
    }
    
    //Create Task
    public Task createTask(Task task) {
    	return taskRepository.save(task);
    }
    
    //Update Task
    
    public Task updateTask(Task task) {
    	return taskRepository.save(task);
    }
    //Find task by name
    public Task findTaskByUser(Task task) {
    	return taskRepository.findTaskByUser(task);
    }
    
    
    
    //Delete
    public String delete(Task task) {
    	taskRepository.delete(task);
    	return null;
    }
    
    //Sort High
    public List<Task> sortHigh(){
		return taskRepository.findByOrderByPriority();
    }
    
    
    //Sort 
    public List<Task> sortLow(){
		return taskRepository.findByOrderByPriorityDesc();
    }
}








