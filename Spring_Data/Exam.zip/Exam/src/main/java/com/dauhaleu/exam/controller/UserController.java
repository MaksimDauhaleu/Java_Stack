package com.dauhaleu.exam.controller;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.dauhaleu.exam.model.Task;
import com.dauhaleu.exam.model.User;
import com.dauhaleu.exam.service.UserService;



@Controller
public class UserController {
 private final UserService userService;

 
 public UserController(UserService userService) {
     this.userService = userService;
 }

 
 //Regist
 @RequestMapping("/registration")
 public String registerForm(@ModelAttribute("user") User user) {
     return "registrationPage.jsp";
 }
 @RequestMapping("/login")
 public String login() {
     return "loginPage.jsp";
 }
 
 
 //Regist
 @RequestMapping(value="/registration", method=RequestMethod.POST)
 public String registerUser(@Valid @ModelAttribute("user") User user, BindingResult result, HttpSession session) {
	 if(!user.getPassword().equals(user.getPasswordConfirmation())) {
		 result.rejectValue("passwordConfirmation", "error.user","Password confirmation is failed");
		 return "registrationPage.jsp";
	 }
	 if(result.hasErrors()) {
		 result.rejectValue("password", "error.user","Try again");
		 return"registrationPage.jsp";
	 }
	 if(userService.findByEmail(user.getEmail()) != null){
		 result.rejectValue("email", "error.user","Email exist");
		 return "registrationPage.jsp";
	 }else {
		 User some = new User(user);
		 userService.registerUser(some);
		 return "redirect:/login";
	 }
 }
 
 //Login
 @RequestMapping(value="/login", method=RequestMethod.POST)
 public String loginUser(@RequestParam("email") String email, @RequestParam("password") String password, Model model, HttpSession session) {
    	Boolean user = userService.authenticateUser(email, password);
    	if(user == true) {
    		User test = userService.findByEmail(email);
    		session.setAttribute("id", test.getId());
    		session.setAttribute("loggedIn", true);
    		return "redirect:/home";
    	}else {
    		String error = "Please make sure that you have entered your login and password correctly.";
    		model.addAttribute("error",error);
    		return "loginPage.jsp";
    	}
 }

 	
 
 
 
 //Home
 @RequestMapping("/home")
 public String home(HttpSession session, Model model) {
	 //ID Check
	 Long id = (Long) session.getAttribute("id");
	 if(id == null) {
		 return"loginPage.jsp";
	 }
	 List<Task> tasks = userService.findTasks();
	 User user = userService.findUserById(id);
     model.addAttribute("user", user);
     model.addAttribute("tasks",tasks);
	 return "homePage.jsp";
 }

//Sorted by High
 
 @RequestMapping("/home/byHigh")
 public String byHigh(HttpSession session, Model model) {
	 //ID Check
	 Long id = (Long) session.getAttribute("id");
	 if(id == null) {
		 return"loginPage.jsp";
	 }
	 List<Task> tasks = userService.sortHigh();
	 User user = userService.findUserById(id);
     model.addAttribute("user", user);
     model.addAttribute("tasks",tasks);
	 return "homePage.jsp";
 }
 
 
 // Sort b
 @RequestMapping("/home/byLow")
 public String byLow(HttpSession session, Model model) {
	 //ID Check
	 Long id = (Long) session.getAttribute("id");
	 if(id == null) {
		 return"loginPage.jsp";
	 }
	 List<Task> tasks = userService.sortLow();
	 User user = userService.findUserById(id);
     model.addAttribute("user", user);
     model.addAttribute("tasks",tasks);
	 return "homePage.jsp";
 }
 
 
 
 
 
 //Create Page
 @RequestMapping("/createPage")
 public String createPage(@ModelAttribute("task") Task task,Model model){
	 List<User> users = userService.findUsers();
	 model.addAttribute("users", users);
	 return"createPage.jsp";
 }
 
 //Create Task Post 
 @RequestMapping(value="/createTask", method=RequestMethod.POST)
 public String createTask(@Valid @ModelAttribute("task") Task task,BindingResult result,HttpSession session) {
	 Long id = (Long) session.getAttribute("id");
	 if(id == null) {
		 return"loginPage.jsp";
	 }
	 User user = userService.findUserById(id);
	 Task some_2 = new Task(task);
	 User user_x = some_2.getUser();
	 if(result.hasErrors()) {
		 return"createPage.jsp";
	 }
	 if(user_x.getTasks().size() >= 5) {
		 result.rejectValue("user", "error.user", "Too many assigments");
		 return "createPage.jsp";
	 }else {
		 task.setCreator(user);
		 Task some = new Task(task);
		 userService.createTask(some);
		 return"redirect:/home";
	 }
	 
	 
 }
 
 //Esit Task Page
 @RequestMapping("/editPage/{task_id}")
 public String editPage(@ModelAttribute("task") Task taskf,@PathVariable("task_id") Long task_id,Model model,HttpSession session) {
	 Task task = userService.findTaskById(task_id);
	 Long id = (Long) task.getCreator().getId();
	 Long id_s = (Long) session.getAttribute("id");
	 if(id_s == null) {
		 return"loginPage.jsp";
	 }
	 if(!id_s.equals(id)) {
		 return"redirect:/home";
	 }
		 model.addAttribute("editTask",task);
		 System.out.println(task.getId());
		 
		 List<User> users = userService.findUsers();
		 model.addAttribute("users", users);
		 return"editPage.jsp";
 }
 
 //Esit Task Page
 @RequestMapping(value = "/editPage/{task_id}", method=RequestMethod.POST)
 public String edit(@Valid @ModelAttribute("task") Task taskf,BindingResult result,@PathVariable("task_id") Long task_id,Model model) {
	 if (result.hasErrors()) {
		 List<User> users = userService.findUsers();
		 model.addAttribute("users", users);
		 Task task = userService.findTaskById(task_id);
		 model.addAttribute("editTask",task);
         return "editPage.jsp";
     } else {
    	 taskf.setId(task_id);
    	 taskf.setCreator(userService.findTaskById(task_id).getCreator());
         userService.updateTask(taskf);
         return "redirect:/home";
     }
 }
 
 //Show PAge
 
 
 @RequestMapping("/showPage/{id}")
 public String show(Model model,@PathVariable("id") Long id,HttpSession session) {
	 Task task = userService.findTaskById(id);
	 Long id_user = (Long) session.getAttribute("id");
	 if(id == null) {
		 return"loginPage.jsp";
	 }
	 User user = userService.findUserById(id_user);
	 model.addAttribute("task",task);
	 model.addAttribute("user",user);
	 return"showPage.jsp";
 }
 
//Delete
 @RequestMapping("/delete/{id}")
 public String delete(@PathVariable("id") Long id) {
	 Task task = userService.findTaskById(id);
	 userService.delete(task);
	 return"redirect:/home";
 }
 
 
 //My assignments
 @RequestMapping("/myAssignments")
 public String myAssignments(Model model,HttpSession session) {
	 Long id = (Long) session.getAttribute("id");
	 if(id == null) {
		 return"loginPage.jsp";
	 }
	 User user = userService.findUserById(id);
	 List<Task> tasks = user.getTasks();
	 System.out.print(user.getTasks());
	 model.addAttribute("user",user);
	 model.addAttribute("tasks",tasks);
	 return"myAssignments.jsp";
 }
 
 
 
 
 
 //LogOut
 @RequestMapping("/logout")
 public String logout(HttpSession session) {
	 session.invalidate();
	 return"redirect:/login";
 }
}